<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JoinedSpecialProgram extends Model
{
    protected $table = 'joined_special_programs';

    public $timestamps = false;

    // relationships
    public function specialProgram()
    {
        return $this->hasOne(SpecialProgram::class, 'id', 'special_pid');
    }
    
    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }
}
