<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecialVideoLink extends Model
{
    protected $table = 'special_video_links';

    public $timestamps = false;

    public function video()
    {
        return $this->hasOne(Video::class, 'id', 'video_id');
    }
}
