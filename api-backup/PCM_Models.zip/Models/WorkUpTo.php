<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WorkUpTo extends Model
{
    protected $table = 'workupto';

    public $timestamps = false;

    // relationships
    public function video()
    {
        return $this->hasOne(Video::class, 'id', 'video_id');
    }
}
