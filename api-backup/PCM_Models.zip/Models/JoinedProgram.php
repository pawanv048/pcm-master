<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JoinedProgram extends Model
{
    protected $table = 'joined_programs';

    public $timestamps = false;

    // relationships
    public function program()
    {
        return $this->hasOne(Program::class, 'id', 'program_id');
    }
}
