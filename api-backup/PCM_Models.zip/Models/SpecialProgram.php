<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecialProgram extends Model
{
    protected $table = 'special_programs';

    public $timestamps = false;

    public static $imagesPath = 'media/programs/';

    // relationships
    // public function exercises()
    // {
    //     return $this->hasMany(ProgramExercise::class, 'program_id', 'id');
    // }
}
