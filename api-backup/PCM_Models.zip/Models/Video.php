<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Video extends Model
{
    protected $table = 'videos';

    public $timestamps = false;

    public $incrementing = false;

    protected $casts = [
        'id' => 'string'
    ];

    // relationships
    public function category()
    {
        return $this->hasOne(Category::class, 'id', 'cat_id')->select('id', 'title');
    }
}
