<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecialProgramLink extends Model
{
    protected $table = 'special_program_links';

    public $timestamps = false;

    public function specialProgram()
    {
        return $this->hasOne(SpecialProgram::class, 'id', 'other_pid');
    }
}
