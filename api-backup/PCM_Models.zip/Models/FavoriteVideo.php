<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FavoriteVideo extends Model
{
    protected $table = 'favorite_videos';

    public $timestamps = false;

    // relationships
    public function video()
    {
        return $this->hasOne(Video::class, 'id', 'video_id');
    }
}
