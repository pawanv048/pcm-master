<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    protected $table = 'programs';

    public $timestamps = false;

    // relationships
    public function exercises()
    {
        return $this->hasMany(ProgramExercise::class, 'program_id', 'id');
    }
}
