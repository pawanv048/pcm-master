<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'categories';

    public static $imagesPath = 'media/library/images/';

    public static $videosPath = 'media/library/videos/';

    public $timestamps = false;
}
