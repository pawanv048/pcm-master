<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecialSectionLink extends Model
{
    protected $table = 'special_section_links';

    public $timestamps = false;

    public function category()
    {
        return $this->hasOne(Category::class, 'id', 'cat_id');
    }
}
