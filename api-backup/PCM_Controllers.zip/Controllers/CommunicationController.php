<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; 
use App\Models\Chat; 
use App\Models\ChatRoom; 
use App\Models\Notification;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

class CommunicationController extends Controller
{
    
    public function updateChatStatus(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $user->chat_status = $request->chat_status;
            $user->save();
            return response()->json(['status' => 'success', 'data' => $user]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function getAllChats(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $rooms = ChatRoom::where('user_id', '!=', 0)->with(['user'])->orderBy('last_time', 'desc')->get();
            $arr = [];
            foreach($rooms as $room){
                $unread = Chat::where(array('user_id' => $room['user_id'], 'admin_read' => 0))->count();
                $room->unread = $unread;
                $arr[] = $room;
            }
            return response()->json(['status' => 'success', 'data' => $arr]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function getChat(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            // get chat
            $chat = Chat::where('user_id', $request->user_id)->get();
            if($user->type === 'user'){
                // set all read
                Chat::where(array('user_id'=>$request->user_id, 'has_read'=>0))->update(['has_read' => 1]);
            }
            else{
                // set all read
                Chat::where(array('user_id'=>$request->user_id, 'admin_read'=>0))->update(['admin_read' => 1]);
            }
            return response()->json(['status' => 'success', 'data' => $chat]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getUnreadChatCount(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $count = Chat::where(array('user_id' => $request->user_id, 'has_read' => 0))->count();
            return response()->json(['status' => 'success', 'data' => $count]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function sendMessage(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $chat = new Chat();
            $chat->sender = $request->sender;
            $chat->user_id = $request->user_id;
            $chat->message = $request->message;
            if($request->sender == 'user'){
                $chat->has_read = 1;
            }
            if($request->sender == 'admin'){
                $chat->admin_read = 1;
            }
            $chat->user_time = $request->user_time;
            $chat->save();
            
            // update chat room
            $room = ChatRoom::where('user_id', $request->user_id)->first();
            if($room){
                // update room
                $room->last_message = $request->message;
                $room->last_time = now();
                $room->save();
            }
            else{
                // add room
                $room = new ChatRoom();
                $room->user_id = $request->user_id;
                $room->last_message = $request->message;
                $room->last_time = now();
                $room->save();
            }
            
            if($request->sender == 'admin'){
                // send push
                $title = 'New Message By Admin';
                $body = $request->message;
                $type = 'Message';
                $this->sendPushById($request->user_id, $title, $body, $type);
            }
            
            return response()->json(['status' => 'success', 'msg' => 'done', 'data' => $chat]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getNotifications(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            // get all
            $notifications = Notification::where('user_id', $request->user_id)->get();
            // set all read
            Notification::where(array('user_id'=>$request->user_id, 'has_read'=>0))->update(['has_read' => 1]);
            return response()->json(['status' => 'success', 'data' => $notifications]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getUnreadNotificationCount(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $count = Notification::where(array('user_id' => $request->user_id, 'has_read' => 0))->count();
            return response()->json(['status' => 'success', 'data' => $count]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function clearNotifications(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            Notification::where(array('user_id' => $request->user_id))->delete();
            return response()->json(['status' => 'success', 'msg' => 'done']);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function sendEmail(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $recepients = $request->recepients;
            if($recepients === 'all'){
                $emails = [];
                $allUsers = User::all();
                foreach ($allUsers as $row) {
                    if($row['type'] !== 'admin'){
                        $emails[] = $row['email'];
                    }
                }
                $recepients = $emails;
            }
            else{
                $recepients = explode(",", $recepients);
            }
            $subject = $request->subject;
            $body = $request->body;
            $result = $this->sendMail($recepients, $subject, $body);
            return response()->json(['status' => 'success', 'sentTo' => $recepients]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function sendNotification(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $userIds = $request->recepients;
            $subject = $request->subject;
            $body = $request->body;
            if($userIds === 'all'){
                // topic messaging
                $this->sendFcmPush('/topics/public_notification', $subject, $body, 'notification');
            }
            else{
                $userIds = explode(",", $userIds);
                foreach ($userIds as $id) {
                    $this->sendPushById(str_replace(' ', '', $id), $subject, $body, 'notification');
                }
            }
            return response()->json(['status' => 'success']);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    // Send Push Notification
    private function sendPushById($userId, $title, $body, $type)
    {
        $user = User::find($userId);
        if ($user) {
            $this->sendFcmPush($user->push_token, $title, $body, $type);
        } 
        else {
            return response()->json(['status' => 'failed', 'msg' => 'User not found']);
        }
    }
    
    private function sendFcmPush($token, $title, $body, $type){
        try {
            $serverkey = env('FIREBASE_SERVER_KEY');
            $fcmUrl = 'https://fcm.googleapis.com/fcm/send';
            $data = [
                "to" => $token,
                "notification" =>
                [
                    "title" => $title,
                    "body" => $body,
                ],
                "data" => [
                    'type' => $type
                ],
            ];
            $dataString = json_encode($data);
            $headers = [
                'Authorization: key=' . $serverkey,
                'Content-Type: application/json',
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

            curl_exec($ch);

            return response()->json(['status' => 'success', 'msg' => 'Notification Sent!']);
        } catch (Exception $e) {
            return response()->json(['status' => 'failed', 'msg' => 'error occured' . $e]);
        }
    }
    
    /*Send Email*/
    private function sendMail($emails, $subject, $body)
    {
        $mail = new PHPMailer(true);                            // Passing `true` enables exceptions
        try {
            // Server settings
            $mail->SMTPDebug = false;                                    // Enable verbose debug output
            $mail->isSendMail();                                         // Set mailer to use SMTP
            $mail->Host = 'smtp.office365.com';                                     // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                                  // Enable SMTP authentication
            $mail->Username = 'will@posturecoreandmore.com';             // SMTP username
            $mail->Password = 'Saifal!5050';              // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('will@posturecoreandmore.com', 'PostureCoreAndMore');
            // $mail->addAddress($email);    // Add a recipient, Name is optional

            //Content
            $mail->isHTML(true);                                                                 
            $mail->Subject = $subject;
            $mail->Body = $body; 
            
            foreach ($emails as $email) {
                    try {
                        $mail->addAddress(str_replace(' ', '', $email));
                    } 
                    catch (Exception $e) {
                        echo 'Invalid address skipped: ' . htmlspecialchars($row['email']) . '<br>';
                        continue;
                    }
                
                    try {
                        $mail->send();
                    } catch (Exception $e) {
                        //Reset the connection to abort sending this message
                        //The loop will continue trying to send to the rest of the list
                        $mail->getSMTPInstance()->reset();
                    }
                    //Clear all addresses and attachments for the next iteration
                    $mail->clearAddresses();
                    $mail->clearAttachments();
            }
            
            return response()->json(['status' => 'success', 'msg' => 'Email Sent']);;
        } catch (Exception $e) {
            return response()->json(['status' => 'failed', 'msg' => 'Email Not Sent' . $e]);
        }
    }
    
    

}
