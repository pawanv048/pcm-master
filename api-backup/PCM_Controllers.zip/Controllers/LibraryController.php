<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category; 
use App\Models\Library; 
use App\Models\Video; 
use App\Models\FavoriteVideo; 
use App\Models\SpecialSectionLink; 
use App\Models\WorkUpTo;
use App\Models\User; 
use Tymon\JWTAuth\JWTAuth;
use File;

class LibraryController extends Controller
{

    protected $jwt;

    public function __construct(JWTAuth $jwt)
    {
        $this->jwt = $jwt;
    }
    
    // just for testing
    public function uploadVideo(Request $request)
    {
        if ($request->hasFile('video')) {
            try {
                $file_name = $this->addAttachments($request->file('video'), Category::$videosPath);
                return 'fileName: '.$file_name;
            } catch (Exception $ex) {
                return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
            }
        }
        else{
            return 'else';
        }
        // if($request::hasFile('video')){
        //     // return 'hello';
        //     $file = $request->file('video');
        //     $filename = $file->getClientOriginalName();
        //     $path = public_path().'/uploads/';
        //     return $file->move($path, $filename);
        // }
    }
 
    public function addCategory(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $category = new Category();
                $category->parent_id = $request->parent_id;
                $category->title = $request->title;
                if ($request->hasFile('image')) {
                    try {
                        $file_name = $this->addAttachments($request->file('image'), Category::$imagesPath);
                        $category->image = $file_name;
                    } catch (Exception $ex) {
                        return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                    }
                }
                $category->save();
                return response()->json(['status' => 'success', 'msg' => 'category added', 'data' => $category]);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }
        else{
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function updateCategory(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $category = Category::where('id', $request->cat_id)->first();
                if($category){
                    $category->title = $request->title;
                    if ($request->hasFile('image')) {
                        try {
                            $file_name = $this->addAttachments($request->file('image'), Category::$imagesPath);
                            $category->image = $file_name;
                        } catch (Exception $ex) {
                            return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                        }
                    }
                    $category->save();
                    return response()->json(['status' => 'success', 'msg' => 'category updated', 'data' => $category]);
                }
                else{
                    return response()->json(['status' => 'failed', 'msg' => 'Category not found']);
                }
                
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }
        else{
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function deleteCategory(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $category = Category::where('id', $request->cat_id)->first();
                if($category){
                    $subCats = Category::where('parent_id', $category->id)->get();
                    foreach($subCats as $subCat){
                        $videos = Video::where('cat_id', $subCat['id'])->get();
                        foreach($videos as $video){
                            $this->deleteVideo($video['id']);
                        }
                        SpecialSectionLink::where('cat_id', $subCat['id'])->delete();
                        $subCat->delete();
                    }
                    $videos = Video::where('cat_id', $category->id)->get();
                    foreach($videos as $video){
                        $this->deleteVideo($video['id']);
                    }
                    SpecialSectionLink::where('cat_id', $category->id)->delete();
                    $category->delete();
                    return response()->json(['status' => 'success', 'msg' => 'category deleted']);
                }
                else{
                    return response()->json(['status' => 'failed', 'msg' => 'Category not found']);
                }
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }
        else{
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getCategories(Request $request)
    {
        $cats = Category::all();
        return response()->json($cats);
    }

    public function addCategoryVideo(Request $request)
    {
        try {
            $video = new Video();
            $video->id = $request->id;
            $video->cat_id = $request->cat_id;
            $video->title = $request->title;
            if ($request->hasFile('thumbnail')) {
                // $video->thumbnail = 'thumb';
                try {
                    $file_name = $this->addAttachments($request->file('thumbnail'), Category::$imagesPath);
                    $video->thumbnail = $file_name;
                } catch (Exception $ex) {
                    return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                }
            }
            if ($request->hasFile('video')) {
                // $video->file_name = 'dummy';
                try {
                    $video_name = $this->addAttachments($request->file('video'), Category::$videosPath);
                    $video->file_name = $video_name;
                } catch (Exception $ex) {
                    return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                }
            }
            
            $video->save();
            return response()->json(['status' => 'success', 'msg' => 'video added', 'data' => $video]);
        } catch (\Illuminate\Database\QueryException $e) {
            return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
        }
    }
    
    public function deleteCategoryVideo(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $response = $this->deleteVideo($request->video_id);
                return $response;
                // $video = Video::where('id', $request->video_id)->first();
                // if($video){
                //     $thumbnailPath = public_path(Category::$imagesPath.$video->thumbnail);
                //     $videoPath = public_path(Category::$videosPath.$video->file_name);
                //     if (File::exists($thumbnailPath)) {
                //         File::delete($thumbnailPath);
                //     }
                //     if (File::exists($videoPath)) {
                //         File::delete($videoPath);
                //     }
                    
                //     $video->title = 'Video Deleted';
                //     $video->thumbnail = 'deleted.png';
                //     $video->status = 'deleted';
                //     $video->save();
                //     return response()->json(['status' => 'success', 'msg' => 'Video deleted', 'data' => $video, 'videoPath' => $videoPath]);
                // }
                // else{
                //     return response()->json(['status' => 'failed', 'msg' => 'Video not found']);
                // }
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }
        else{
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    private function markLikedVideos($user, $videos){
        $likedVideos = FavoriteVideo::where('user_id', $user->id)->get();
        $str = '';
        foreach ($likedVideos as $likedVideo) {
            $str = $str.$likedVideo->video_id.',';
        }
        foreach ($videos as $video) {
            if(str_contains($str, $video->id.',')){
                $video->liked = '1';
            }
            else{
                $video->liked = '0';
            }
        }
        return $videos;
    }

    public function getCategoryVideos(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first(); 
        if ($user) {
            $videos = Video::where(array('cat_id' => $request->cat_id, 'status' => 'active'))->with(['category'])->get();
            $videos = $this->markLikedVideos($user, $videos);
            return response()->json(['status' => 'success', 'data' => $videos]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function searchVideos(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $videos = Video::where('title', 'LIKE', '%'.($request->keyword).'%')->with(['category'])->get();
            $videos = $this->markLikedVideos($user, $videos);
            return response()->json(['status' => 'success', 'data' => $videos]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function addRemoveFavoriteVideo(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            // check eixsts
            $fvideo = FavoriteVideo::where(array('user_id' => $request->user_id, 'video_id' => $request->video_id))->first();
            if($fvideo){
                $fvideo->delete();
                return response()->json(['status' => 'failed', 'msg' => 'Removed']);
            }
            else{
                $fvideo = new FavoriteVideo();
                $fvideo->video_id = $request->video_id;
                $fvideo->user_id = $request->user_id;
                $fvideo->save();
                return response()->json(['status' => 'success', 'msg' => 'Added']);
            }

            // if($request->type == 'add'){
            //     // add
            //     $fvideo = new FavoriteVideo();
            //     $fvideo->video_id = $request->video_id;
            //     $fvideo->user_id = $request->user_id;
            //     $fvideo->save();
            // }
            // else{
            //     // remove
            //     $fvideo = FavoriteVideo::where(array('video_id' => $request->video_id, 'user_id' => $request->user_id))->first();
            //     if($fvideo){
            //         $fvideo->delete();
            //     }
            // }
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getFavoriteVideos(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $videos = FavoriteVideo::where('user_id', $request->user_id)->with(['video'])->get();
            return response()->json(['status' => 'success', 'data' => $videos]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function addWorkUpTo(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            // check eixsts
            $workUpTo = WorkUpTo::where(array('user_id' => $request->user_id, 'video_id' => $request->video_id))->first();
            if($workUpTo){
                return response()->json(['status' => 'failed', 'msg' => 'Already added!']);
            }
            $work = new WorkUpTo();
            $work->user_id = $request->user_id;
            $work->video_id = $request->video_id;
            $work->title = $request->title;
            $work->save();
            return response()->json(['status' => 'success', 'msg' => 'done']);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function deleteWorkUpTo(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $work = WorkUpTo::find($request->wid);
            if($work){
                $work->delete();
            }
            return response()->json(['status' => 'success', 'msg' => 'done']);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getWorkUpToList(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $list = WorkUpTo::where('user_id', $request->user_id)->with(['video'])->get();
            return response()->json(['status' => 'success', 'data' => $list]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    private function deleteVideo($video_id){
        $video = Video::where('id', $video_id)->first();
        if($video){
            $thumbnailPath = public_path(Category::$imagesPath.$video->thumbnail);
            $videoPath = public_path(Category::$videosPath.$video->file_name);
            if (File::exists($thumbnailPath)) {
                File::delete($thumbnailPath);
            }
            if (File::exists($videoPath)) {
                File::delete($videoPath);
            }
            
            $video->title = 'Video Deleted';
            $video->thumbnail = 'deleted.png';
            $video->status = 'deleted';
            $video->save();
            return response()->json(['status' => 'success', 'msg' => 'Video deleted', 'data' => $video, 'videoPath' => $videoPath]);
        }
        else{
            return response()->json(['status' => 'failed', 'msg' => 'Video not found']);
        }
    }

    private function addAttachments($file, $path)
    {
        $destination = public_path($path); 
        $fileName = time() . '_' . $file->getClientOriginalName();
        $file->move($destination, $fileName);
        return $fileName;
    }
}
