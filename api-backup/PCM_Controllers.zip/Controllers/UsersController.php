<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use Tymon\JWTAuth\JWTAuth;
use Illuminate\Support\Facades\Storage;

class UsersController extends Controller
{

    protected $jwt;

    public function __construct(JWTAuth $jwt)
    {
        $this->jwt = $jwt;
    }

    public function sendEmail(Request $request)
    {
        $response = $this->sendMail($request->email, $request->subject, $request->body);
        return $response;
    }
    
    public function getUsers(Request $request)
    {
        $user = User::where('access_token', $request->access_token)->first();
        if ($user) {
            // $limit = 10;
            // $page_no = ($request->page_no * $limit) - $limit;
            // $users = User::where('type', 'user')->limit($limit)->offset($page_no)->orderBy('id', 'desc')->get();
            $users = User::where('type', 'user')->orderBy('id', 'desc')->get();
            return response()->json(['status' => 'success', 'data' => $users]);
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }
    
    public function searchUsers(Request $request)
    {
        $user = User::where('access_token', $request->access_token)->first();
        if ($user) {
            $users = User::where('email', 'LIKE', '%'.($request->keyword).'%')->orWhere('fname', 'LIKE', '%'.($request->keyword).'%')->orWhere('lname', 'LIKE', '%'.($request->keyword).'%')->orderBy('id', 'desc')->get();
            return response()->json(['status' => 'success', 'data' => $users]);
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }

    public function registerUser(Request $request)
    {
        $user = User::where(array('email' => $request->email))->first();
        if($user){
            return response()->json(['status' => 'failed', 'msg' => 'User already exists']);
        }
        try {
            $user = new User();
            // $user->id = Str::uuid();
            $user->fname = $request->fname;
            $user->lname = $request->lname;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->photo = '';
            $user->age = '';
            $user->goal = '';
            $user->push_token = '';

            $c_claims = array('abckdses' => 'kklsjdfkl');
            $token = $this->jwt->claims($c_claims)->fromUser($user);

            $user->access_token = $token;
            $user->save();
            $data = User::where(array('email' => $request->email))->first();
            return response()->json(['status' => 'success', 'msg' => 'user created successfully', 'data' => $data]);
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode = $e->errorInfo[1];
            if ($errorCode == 1062) {
                return response()->json(['status' => 'failed', 'msg' => 'duplicate entry']);
            }
            return response()->json(['status' => 'failed', 'msg' => 'failed to create user' . $e]);
        }
    }

    public function forgotPassword(Request $request)
    {
        $user = User::where(array('email' => $request->email))->get();
        if (!empty($user)) {
            $newPass = substr(str_shuffle("0123456789abcdefghijklmnopqrstvwxyz"), 0, 6);
            User::where(array('email' => $request->email))->update(array('password' => Hash::make($newPass)));
            $subject = 'Forgot Password';
            $body = 'Here is your temporary password for account login (you can change in app after login): '.$newPass ;
            $response = $this->sendMail($request->email, $subject, $body);
            return $response;
        } else {
            return response()->json(array('status' => 'failed', 'msg' => 'Email not found'), 200);
        }
    }

    public function changePassword(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            if (!Hash::check($request->old_password, $user->password)) {
                return response()->json(['status' => 'error', 'msg' => 'Wrong old password'], 200);
            }
            $user->password = Hash::make($request->password);
            $user->save();
            return response()->json(['status' => 'success', 'msg' => 'Password udpated.']);
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }

    public function updateAdmin(Request $request)
    {
        $user = User::where('access_token', $request->access_token)->first();
        if ($user) {
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->save();
            return response()->json(['status' => 'success', 'msg' => 'profile updated.']);
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }
    
    public function updateStatus(Request $request)
    {
        $u = User::where('access_token', $request->access_token)->first();
        if ($u) {
            $user = User::where('id', $request->user_id)->first();
            if($user){
                $user->status = $request->status;
                $user->save();
                return response()->json(['status' => 'success', 'msg' => 'status updated.']);
            }
            else{
                return response()->json(['status' => 'failed', 'msg' => 'user not found!']);
            }
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }
    
    public function updateFreeStatus(Request $request)
    {
        $u = User::where('access_token', $request->access_token)->first();
        if ($u) {
            $user = User::where('id', $request->user_id)->first();
            if($user){
                $user->free_user = $request->free_user;
                $user->save();
                return response()->json(['status' => 'success', 'msg' => 'free status updated.']);
            }
            else{
                return response()->json(['status' => 'failed', 'msg' => 'user not found!']);
            }
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }

    public function updatePushToken(Request $request)
    {
        $user = User::where('access_token', $request->access_token)->first();
        if ($user) {
            $user->push_token = $request->push_token;
            $user->save();
            return response()->json(['status' => 'success', 'msg' => 'push token updated.']);
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }

    public function updateSubscribeStatus(Request $request)
    {
        $user = User::where('access_token', $request->access_token)->first();
        if ($user) {
            $user->subscriber = $request->subscriber;
            $user->save();
            return response()->json(['status' => 'success', 'msg' => 'Updated subscribe status!']);
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }

    public function updateProfile(Request $request)
    {
        // return public_path('profile.png');
        $user = User::where('access_token', $request->access_token)->first();
        if ($user) {
            $user->fname = $request->fname;
            $user->lname = $request->lname;
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->subscriber = $request->subscriber;
            if ($request->hasFile('image')) {
                try {
                    $oldPhoto = $user->photo;
                    $file_name = $this->addAttachments($request);
                    $user->photo = $file_name;
                    // delete old photo
                    $this->deleteAttachment($oldPhoto);
                } 
                catch (Exception $ex) {
                    return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                }
            }
            $user->save();
            return response()->json(['status' => 'success', 'msg' => 'Profile updated!', 'data' => $user ]);
        } 
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }
    
    public function deleteUser(Request $request)
    {
        $u = User::where('access_token', $request->access_token)->first();
        if ($u) {
            $user = User::where('id', $request->user_id)->first();
            if($user){
                // clean all data
                $user->delete();
                FavoriteVideo::where('user_id', $request->user_id)->delete();
                JoinedProgram::where('user_id', $request->user_id)->delete();
                JoinedSpecialProgram::where('user_id', $request->user_id)->delete();
                Notification::where('user_id', $request->user_id)->delete();
                $programs = Program::where('user_id', $request->user_id)->get();
                foreach($programs as $program){
                    ProgramExercise::where('program_id', $program['id'])->delete();
                    $program->delete();
                }
                WorkUpTo::where('user_id', $request->user_id)->delete();
                return response()->json(['status' => 'success', 'msg' => 'user deleted.']);
            }
            else{
                return response()->json(['status' => 'failed', 'msg' => 'user not found!']);
            }
        } else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid Access!']);
        }
    }

    public function addAttachments($request)
    {
        $file = $request->file('image');
        $destination = public_path(User::$photoPath);
        $file_name = time() . '_' . $file->getClientOriginalName();
        $file->move($destination, $file_name);
        return $file_name;
    }

    public function deleteAttachment($photoName)
    {
        $path = public_path(User::$photoPath).'/'.$photoName;
        if(file_exists($path)) {
            @unlink($path);
        }
    }

    /*Send Email*/
    private function sendMail($email, $subject, $body)
    {
        $mail = new PHPMailer(true);                            // Passing `true` enables exceptions
        try {
            // Server settings
            $mail->SMTPDebug = false;                                    // Enable verbose debug output
            $mail->isSendMail();                                         // Set mailer to use SMTP
            $mail->Host = 'smtp.office365.com';                                     // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                                  // Enable SMTP authentication
            $mail->Username = 'will@posturecoreandmore.com';             // SMTP username
            $mail->Password = 'Saifal!5050';              // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('will@posturecoreandmore.com', 'PostureCoreAndMore');
            $mail->addAddress($email);    // Add a recipient, Name is optional

            //Content
            $mail->isHTML(true);                                                                     // Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body    = $body;                        // message

            $mail->send();
            return response()->json(['status' => 'success', 'msg' => 'Email Sent']);;
        } catch (Exception $e) {
            return response()->json(['status' => 'failed', 'msg' => 'Email Not Sent' . $e]);
        }
    }
}
