<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Age; 
use App\Models\Goal; 
use App\Models\User; 
use App\Models\Slide; 
use App\Models\Equipment; 
use App\Models\Category;
use App\Models\SpecialProgram;
use App\Models\JoinedSpecialProgram;

class CommonController extends Controller
{

    public function getDashboardData(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $users = 0;
            $subs = 0;
            $joined = 0; // programs joined
            $sales = 0;
    
            $users = User::count() - 1; // admin exclued
            $subs = User::where(array('subscriber' => '1'))->count();
            $joined = JoinedSpecialProgram::count();
            $list = JoinedSpecialProgram::where('user_id', '!=', '0')->with(['specialProgram'])->get();
            foreach($list as $item){
                $obj = json_decode($item, true);
                $price = $obj['special_program']['price'];
                if($price != '0'){
                    $sales++;
                }
            }
            return response()->json(['user' => $users, 'subs' => $subs, 'joined' => $joined, 'sales' => $sales ]);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function addSlide(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $slide = new Slide();
                $slide->link = $request->link;
                if ($request->hasFile('image')) {
                    try {
                        $file_name = $this->addAttachments($request->file('image'), Slide::$imagesPath);
                        $slide->image = $file_name;
                    } catch (Exception $ex) {
                        return response()->json('Unable to upload file', 500);
                    }
                }
                $slide->save();
                return response()->json(['status' => 'success', 'msg' => 'slide added', 'data' => $slide]);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function deleteSlide(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $slide = Slide::where('id', $request->id)->first();
                if($slide){
                    $slide->delete();
                    return response()->json(['status' => 'success', 'msg' => 'Slide deleted']);
                }
                else{
                    return response()->json(['status' => 'failed', 'msg' => 'Slide not found']);
                }
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getSlides(Request $request)
    {
        $slides = Slide::all();
        return response()->json($slides);
    }

    public function getFilters(Request $r)
    {
        $ages = Age::all();
        $goals = Goal::all();
        return response()->json(['ages' => $ages, 'goals' => $goals]);
    }

    public function getAges(Request $r)
    {
        $ages = Age::all();
        return response()->json($ages);
    }

    public function getGoals(Request $r)
    {
        $goals = Goal::all();
        return response()->json($goals);
    }

    public function addEquipmentNeeds(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $eq = new Equipment();
            $eq->title = $request->title;
            $eq->detail = $request->detail;
            if ($request->hasFile('image')) {
                try {
                    $file_name = $this->addAttachments($request->file('image'), Equipment::$imagesPath);
                    $eq->image = $file_name;
                } catch (Exception $ex) {
                    return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                }
            }
            $eq->save();
            return response()->json(['status' => 'success', 'msg' => 'done']);
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function updateEquipmentNeeds(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            $eq = Equipment::where('id', $request->id)->first();
            if($eq){
                $eq->title = $request->title;
                $eq->detail = $request->detail;
                if ($request->hasFile('image')) {
                    try {
                        $file_name = $this->addAttachments($request->file('image'), Equipment::$imagesPath);
                        $eq->image = $file_name;
                    } catch (Exception $ex) {
                        return response()->json(['status' => 'failed', 'msg' => 'upload failed']);
                    }
                }
                $eq->save();
                return response()->json(['status' => 'success', 'msg' => 'Updated']);
            }
            else{
                return response()->json(['status' => 'failed', 'msg' => 'Equipment not found']);
            }
            
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }
    
    public function deleteEquipmentNeeds(Request $request)
    {
        $user = User::where(array('access_token' => $request->access_token))->first();
        if ($user) {
            try {
                $eq = Equipment::where('id', $request->id)->first();
                if($eq){
                    $eq->delete();
                    return response()->json(['status' => 'success', 'msg' => 'Equipmnet deleted']);
                }
                else{
                    return response()->json(['status' => 'failed', 'msg' => 'Equipmnet not found']);
                }
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'failed', 'msg' => 'failed' . $e]);
            }
        }  
        else {
            return response()->json(['status' => 'failed', 'msg' => 'Invalid access']);
        }
    }

    public function getEquipmentNeeds(Request $request)
    {
        $list = Equipment::all();
        return response()->json($list);
    }

    public function getFileUrls(Request $request)
    {
        $urls = array();
        $urls['LibraryImages'] = 'https://www.'.$request->getHost().'/pcm_mobile_app/public/'.Category::$imagesPath;
        $urls['LibraryVideos'] = 'https://www.'.$request->getHost().'/pcm_mobile_app/public/'.Category::$videosPath;
        $urls['Equipment'] = 'https://www.'.$request->getHost().'/pcm_mobile_app/public/'.Equipment::$imagesPath;
        $urls['Slide'] = 'https://www.'.$request->getHost().'/pcm_mobile_app/public/'.Slide::$imagesPath;
        $urls['SpecialProgram'] = 'https://www.'.$request->getHost().'/pcm_mobile_app/public/'.SpecialProgram::$imagesPath;
        $urls['User'] = 'https://www.'.$request->getHost().'/pcm_mobile_app/public/'.User::$photoPath;
        return $urls;
    }

    private function addAttachments($file, $path)
    {
        $destination = public_path($path);
        $fileName = time() . '_' . $file->getClientOriginalName();
        $file->move($destination, $fileName);
        return $fileName;
    }
}
