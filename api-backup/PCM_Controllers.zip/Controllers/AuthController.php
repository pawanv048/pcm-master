<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Tymon\JWTAuth\JWTAuth;
use Illuminate\Support\Facades\Hash;


class AuthController extends Controller
{
    protected $jwt;

    public function __construct(JWTAuth $jwt)
    {
        $this->jwt = $jwt;
    }


    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function loginUser(Request $request)
    {
        $email = $request->email;
        $password = $request->password;
        // return response()->json(['email' => $email, 'password' => $password], 200);
        try {
            $user = User::where(array('email' => $email))->firstOrFail();
            if (!Hash::check($password, $user->password)) {
                return response()->json(['status' => 'error', 'msg' => 'Icorrect Email or Password'], 404);
            } 
            else {
                $c_claims = array('timezone_offset' => '+00:00');
                $token = $this->jwt->claims($c_claims)->fromUser($user);
                $user->access_token = $token;
                $user->online = 1;
                $user->save();
                $user = User::find($user->id);
                return response()->json([
                    'status' => 'success', 'msg' => 'logged in successfully',
                    'data' => $user
                ]);
            }
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['status' => 'error', 'msg' => 'Icorrect Email or Password'], 404);
        }
    }

    public function isAdminOnline(Request $request)
    {
        try {
            $user = User::where(array('type' => 'admin'))->firstOrFail();
            return response()->json(['status' => 'success', 'data' => $user->chat_status]);
        } 
        catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['status' => 'error', 'msg' => 'Admin not found'], 200);
        }
    }
    
    public function logoutUser(Request $request)
    {
        $user_id = $request->user_id;
        try {
            $user = User::where(array('id' => $user_id))->firstOrFail();
            $user->online = 0;
            $user->save();
            return response()->json(['status' => 'success', 'msg' => 'Logged out successfully']);
        } 
        catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['status' => 'error', 'msg' => 'Icorrect Email'], 200);
        }
    }

    public function socialLogin(Request $request)
    {
        $social_id = $request->social_id;
        $name = $request->name;
        $email = $request->email;
        $photo = $request->photo;
        try {
            $user = User::where(array('social_id' => $social_id))->first();
            if (!$user) {
                // create account
                if($email === ''){
                    return response()->json(['status' => 'error', 'msg' => 'Missing email'], 404);
                }
                try {
                    // check if email already exists
                    $check = User::where(array('email' => $email))->first();
                    if($check){
                        return response()->json(['status' => 'error', 'msg' => 'Account with this email already exists'], 404);
                    }
                    $user = new User();
                    // $user->id = Str::uuid();
                    $user->social_id = $social_id;
                    $user->fname = $name;
                    $user->lname = '';
                    $user->email = $email;
                    $user->password = '';
                    $user->photo = $photo.'';
                    $user->age = '';
                    $user->goal = '';
                    $user->push_token = '';
        
                    $c_claims = array('abckdses' => 'kklsjdfkl');
                    $token = $this->jwt->claims($c_claims)->fromUser($user);
        
                    $user->access_token = $token;
                    $user->save();
                    return response()->json(['status' => 'success', 'msg' => 'Social signup & login successful', 'data' => $user]);
                } catch (\Illuminate\Database\QueryException $e) {
                    return response()->json(['status' => 'failed', 'msg' => 'Social signup failed' . $e]);
                }
            } 
            else {
                $c_claims = array('timezone_offset' => '+00:00');
                $token = $this->jwt->claims($c_claims)->fromUser($user);
                $user->access_token = $token;
                $user->save();
                return response()->json([
                    'status' => 'success', 'msg' => 'Logged in successfully',
                    'data' => $user
                ]);
            }
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['status' => 'error', 'msg' => 'Social login failed'], 404);
        }
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        return response()->json(auth()->user());
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }
}
